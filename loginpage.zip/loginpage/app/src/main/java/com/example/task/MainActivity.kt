package com.example.task

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.M)

    var email = findViewById<EditText>(R.id.email_text)
    var password = findViewById<EditText>(R.id.password_text)
    var btnLogin = findViewById<Button>(R.id.btnLogin)
    var forgot_link = findViewById<TextView>(R.id.forgotPassword)
    var signup_link = findViewById<TextView>(R.id.gotoRegister)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnLogin.setOnClickListener(View.OnClickListener {
            fun onClick(v: View) {
                login()

            }
        })

        signup_link.setOnClickListener(View.OnClickListener {
            fun onClick(v: View) {
                var i = Intent(this, Registration::class.java)
                startActivityForResult(i, 0)
            }

        })

    }

    fun login() {
        Log.d("tag", "Login")

        if (!validate()) {
            onLoginFailed()
            return
        }

        btnLogin.isEnabled = false

        var temail = email.text.toString()
        var tpassword = password.text.toString()


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 0 && resultCode == RESULT_OK) {
            this.finish()

        }
    }


    override fun onBackPressed() {
        // disable going back to the MainActivity
        moveTaskToBack(true)
    }

    fun onLoginSuccess(){

        btnLogin.isEnabled=true
        finish()
    }

    fun onLoginFailed(){
        btnLogin.isEnabled=true
        Toast.makeText(baseContext, "Login failed", Toast.LENGTH_LONG).show()
    }

    fun validate(): Boolean {
        var valid = true
        val temail = email.text.toString()
        val tpassword = password.text.toString()
        if (temail.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(temail).matches()) {
            email.setError("enter a valid email address")
            valid = false
        } else {
            email.setError(null)
        }
        if (tpassword.isEmpty() || tpassword.length < 4 || tpassword.length > 10) {
            password.setError("between 4 and 10 alphanumeric characters")
            valid = false
        } else {
            password.setError(null)
        }
        return valid
    }


}










/*var emaillayout = findViewById<TextInputLayout>(R.id.email_layout)
        var temail =email_layout.editText.toString()

        if(temail !="" && '@' !in email_layout.editText.toString()){

            email_layout.isErrorEnabled=true
            email_layout.error="get yourself together"
            //email_layout.isHelperTextEnabled= false
            //email_layout.helperText=" enter correct format"
            //email_layout.setHelperTextColor(getColorStateList(R.color.colorRed))
        }
        else{
            email_layout.helperText=" correct format"
            email_layout.setHelperTextColor(getColorStateList(R.color.colorAccent))

        }

        var forgot_click= findViewById<TextView>(R.id.forgotPassword)
        forgot_click.setOnClickListener(){
            val i = Intent(this@MainActivity, Registration::class.java)
            startActivity(i)
        }
*/